# SF 369 High School Civics Practice Test

Static single-page quiz. Upload `index.html` as the root entry file to a static host such as GitHub Pages.

The page is self-contained: no build step and no external JavaScript dependencies.
